from __future__ import annotations

from typing import List, Type

import torch
import torch.nn as nn
import torch.nn.functional as F


class BasicBlock(nn.Module):
	expansion = 1

	def __init__(self, in_channels: int, out_channels: int, stride: int = 1) -> None:
		super().__init__()
		self.conv1 = nn.Conv2d(
			in_channels,
			out_channels,
			kernel_size=3,
			stride=stride,
			padding=1,
			bias=False,
		)
		self.bn1 = nn.BatchNorm2d(out_channels)
		self.relu = nn.ReLU(inplace=True)
		self.conv2 = nn.Conv2d(
			out_channels,
			out_channels,
			kernel_size=3,
			stride=1,
			padding=1,
			bias=False,
		)
		self.bn2 = nn.BatchNorm2d(out_channels)

		if stride != 1 or in_channels != out_channels:
			self.shortcut = nn.Sequential(
				nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
				nn.BatchNorm2d(out_channels),
			)
		else:
			self.shortcut = nn.Identity()

	def forward(self, x: torch.Tensor) -> torch.Tensor:
		identity = self.shortcut(x)

		out = self.conv1(x)
		out = self.bn1(out)
		out = self.relu(out)

		out = self.conv2(out)
		out = self.bn2(out)

		out += identity
		out = self.relu(out)
		return out


class ResNet(nn.Module):
	def __init__(
		self,
		block: Type[BasicBlock],
		layers: List[int],
		num_classes: int,
	) -> None:
		super().__init__()
		self.in_channels = 64

		# CIFAR stem: 3x3 conv, no max-pool.
		self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
		self.bn1 = nn.BatchNorm2d(64)
		self.relu = nn.ReLU(inplace=True)

		self.layer1 = self._make_layer(block, 64, layers[0], stride=1)
		self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
		self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
		self.layer4 = self._make_layer(block, 512, layers[3], stride=2)

		self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
		self.fc = nn.Linear(512 * block.expansion, num_classes)

		self._initialize_weights()

	def _make_layer(self, block: Type[BasicBlock], out_channels: int, blocks: int, stride: int) -> nn.Sequential:
		strides = [stride] + [1] * (blocks - 1)
		layers = []
		for s in strides:
			layers.append(block(self.in_channels, out_channels, s))
			self.in_channels = out_channels * block.expansion
		return nn.Sequential(*layers)

	def _initialize_weights(self) -> None:
		for module in self.modules():
			if isinstance(module, nn.Conv2d):
				nn.init.kaiming_normal_(module.weight, mode="fan_out", nonlinearity="relu")
			elif isinstance(module, nn.BatchNorm2d):
				nn.init.constant_(module.weight, 1)
				nn.init.constant_(module.bias, 0)
			elif isinstance(module, nn.Linear):
				nn.init.normal_(module.weight, 0, 0.01)
				nn.init.constant_(module.bias, 0)

	def forward(self, x: torch.Tensor) -> torch.Tensor:
		x = self.conv1(x)
		x = self.bn1(x)
		x = self.relu(x)

		x = self.layer1(x)
		x = self.layer2(x)
		x = self.layer3(x)
		x = self.layer4(x)

		x = self.avgpool(x)
		x = torch.flatten(x, 1)
		x = self.fc(x)
		return x

class PreActBlock(nn.Module):
    """Pre-activation ResNet block — He et al. 2016b (arXiv:1603.05027)."""
    expansion = 1

    def __init__(self, in_channels: int, out_channels: int, stride: int = 1) -> None:
        super().__init__()
        self.bn1   = nn.BatchNorm2d(in_channels)
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3,
                               stride=stride, padding=1, bias=False)
        self.bn2   = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3,
                               stride=1, padding=1, bias=False)

        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Conv2d(in_channels, out_channels,
                                      kernel_size=1, stride=stride, bias=False)
        else:
            self.shortcut = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out      = F.relu(self.bn1(x))
        shortcut = self.shortcut(out)
        out      = self.conv1(out)
        out      = self.conv2(F.relu(self.bn2(out)))
        out     += shortcut
        return out


def resnet18(num_classes: int = 10) -> ResNet:
    return ResNet(PreActBlock, [2, 2, 2, 2], num_classes=num_classes)
